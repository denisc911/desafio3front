import './CardComponent.scss';
import 'bootstrap/dist/css/bootstrap.min.css';

const CardComponent = ({ items, handleClick }) => {
  return (
    <div className="container mt-4">
      <div className="row row-cols-1 row-cols-md-2 row-cols-lg-4">
        {items.map((item, index) => (
          <div className="col mb-4" key={index}>
            <div className="card h-100">
              <img
                src={item.imageUrl}
                className="card-img-top btn btn-link p-0"
                alt={item.title}
                onClick={() => handleClick(item)}
              />
              <div className="card-body">
                <p className="card-text">{item.description}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CardComponent;